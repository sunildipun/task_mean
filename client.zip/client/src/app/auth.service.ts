import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


interface registerResponse {
  success:boolean
}


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  
  constructor(private http: HttpClient) { }

  getUserDetail(loginObject){
    console.log('From auth service', loginObject);
    // return this.http.post('',{
    //   loginObject
    // })
  }

  registerUser(register){
    console.log(register);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    // let options = new RequestOptions({ headers: headers });
    this.http.post<registerResponse>('http://localhost:5000/user',
      register
  )

    return register
  }
}
